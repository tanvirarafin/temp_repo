#!/usr/bin/python 
print 'A' * 116
