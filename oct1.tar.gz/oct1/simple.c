int main(){
	int a = 5;
	int b = a+6;
	return 0;
}
